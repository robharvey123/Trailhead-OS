import { NextResponse } from 'next/server'
import { getAuthenticatedSupabase } from '@/lib/api/auth'
import { supabaseService } from '@/lib/supabase/service'

export async function GET() {
  const auth = await getAuthenticatedSupabase()
  if (!auth.ok) {
    return auth.response
  }

  // Check if source column exists by trying a filtered query
  let sourceColumnExists = true
  const { error: sourceCheckError } = await supabaseService
    .from('calendar_events')
    .select('id')
    .eq('source', 'google')
    .limit(1)
  if (sourceCheckError) {
    sourceColumnExists = false
  }

  // Try a test insert with service role to see if it works
  let testInsertError: string | null = null
  const { data: testEvent, error: insertError } = await supabaseService
    .from('calendar_events')
    .insert({
      title: '__debug_test__',
      start_at: new Date().toISOString(),
      end_at: new Date().toISOString(),
      all_day: false,
      source: 'google',
      external_uid: '__debug_test__',
      read_only: true,
    })
    .select('id')
    .single()
  
  if (insertError) {
    testInsertError = `${insertError.message} (code: ${insertError.code}, details: ${insertError.details}, hint: ${insertError.hint})`
  } else if (testEvent) {
    // Clean up test event
    await supabaseService.from('calendar_events').delete().eq('id', (testEvent as { id: string }).id)
  }

  const supabase = auth.supabase

  // Backfill: set user_id on all calendar_events that are missing it
  const userId = auth.user.id
  const { data: backfilled } = await supabaseService
    .from('calendar_events')
    .update({ user_id: userId })
    .is('user_id', null)
    .select('id')

  // Deduplicate feed events: keep the newest row per (feed_id, external_uid)
  // Use range to get ALL events (Supabase default limit is 1000)
  let allFeedEvents: Array<{ id: string; feed_id: string; external_uid: string }> = []
  let offset = 0
  const PAGE = 1000
  while (true) {
    const { data: page } = await supabaseService
      .from('calendar_events')
      .select('id, feed_id, external_uid, created_at')
      .eq('source', 'feed')
      .not('feed_id', 'is', null)
      .order('created_at', { ascending: false })
      .range(offset, offset + PAGE - 1)
    if (!page || page.length === 0) break
    allFeedEvents = allFeedEvents.concat(page as Array<{ id: string; feed_id: string; external_uid: string }>)
    if (page.length < PAGE) break
    offset += PAGE
  }

  const seenFeedKeys = new Set<string>()
  const feedDupeIds: string[] = []
  for (const row of allFeedEvents) {
    const key = `${row.feed_id}:${row.external_uid}`
    if (seenFeedKeys.has(key)) {
      feedDupeIds.push(row.id)
    } else {
      seenFeedKeys.add(key)
    }
  }

  if (feedDupeIds.length > 0) {
    for (let i = 0; i < feedDupeIds.length; i += 500) {
      const batch = feedDupeIds.slice(i, i + 500)
      await supabaseService.from('calendar_events').delete().in('id', batch)
    }
  }

  // Count events by source (use service role for accurate totals, paginate past 1000 limit)
  const counts = { manual: 0, google: 0, feed: 0, total: 0 }
  let countOffset = 0
  while (true) {
    const { data: page } = await supabaseService
      .from('calendar_events')
      .select('source')
      .range(countOffset, countOffset + PAGE - 1)
    if (!page || page.length === 0) break
    for (const row of page) {
      const s = (row as { source: string }).source as keyof typeof counts
      if (s in counts) counts[s]++
      counts.total++
    }
    if (page.length < PAGE) break
    countOffset += PAGE
  }

  // Get a few sample google events
  const { data: sampleGoogle } = await supabaseService
    .from('calendar_events')
    .select('id, title, start_at, end_at, all_day, source, colour, user_id')
    .eq('source', 'google')
    .order('start_at', { ascending: false })
    .limit(5)

  // Get a few sample feed events
  const { data: sampleFeed } = await supabaseService
    .from('calendar_events')
    .select('id, title, start_at, end_at, all_day, source, colour, user_id')
    .eq('source', 'feed')
    .order('start_at', { ascending: false })
    .limit(5)

  // Get feeds status
  const { data: feeds } = await supabaseService
    .from('calendar_feeds')
    .select('id, name, url, enabled, last_fetched_at, last_error, event_count')

  // Get google tokens
  const { data: tokens } = await supabaseService
    .from('google_tokens')
    .select('id, email, label')

  // Get google calendar selections
  const { data: selections } = await supabaseService
    .from('google_calendar_selections')
    .select('id, google_token_id, gcal_calendar_id, name, enabled, sync_direction')

  // Check what the current month query would return
  const now = new Date()
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString()
  const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59).toISOString()

  const { data: currentMonthEvents, count: monthCount } = await supabaseService
    .from('calendar_events')
    .select('id, title, source', { count: 'exact' })
    .gte('start_at', monthStart)
    .lte('start_at', monthEnd)

  const monthBySource = { manual: 0, google: 0, feed: 0 }
  for (const row of currentMonthEvents ?? []) {
    const s = (row as { source: string }).source as keyof typeof monthBySource
    if (s in monthBySource) monthBySource[s]++
  }

  // Count gcal_sync rows
  const { data: syncRows } = await supabaseService
    .from('gcal_sync')
    .select('id')

  // Count events with null user_id
  const { data: nullUserIdEvents } = await supabaseService
    .from('calendar_events')
    .select('id')
    .is('user_id', null)

  return NextResponse.json({
    sourceColumnExists,
    testInsertError,
    backfilledCount: backfilled?.length ?? 0,
    feedDupesRemoved: feedDupeIds.length,
    nullUserIdCount: nullUserIdEvents?.length ?? 0,
    gcalSyncRowCount: syncRows?.length ?? 0,
    counts,
    currentMonth: {
      range: { start: monthStart, end: monthEnd },
      total: monthCount,
      bySource: monthBySource,
    },
    sampleGoogle,
    sampleFeed,
    feeds,
    googleTokens: tokens,
    googleSelections: selections,
  })
}
