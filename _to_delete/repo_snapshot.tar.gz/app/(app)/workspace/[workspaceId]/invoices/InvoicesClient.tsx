'use client'

import { useCallback, useMemo, useState } from 'react'
import Link from 'next/link'
import { toast } from 'sonner'
import { apiFetch } from '@/lib/api-fetch'
import { currencySymbol } from '@/lib/format'
import type { FinanceInvoice, InvoiceStatus, InvoiceDirection, InvoiceLineItem } from '@/lib/finance/types'
import { INVOICE_STATUSES, INVOICE_STATUS_LABELS, INVOICE_STATUS_COLORS } from '@/lib/finance/types'

type AccountOption = { id: string; name: string; address_line1: string | null; address_line2: string | null; city: string | null; state: string | null; postal_code: string | null; country: string | null; email: string | null; phone: string | null }

export default function InvoicesClient({ workspaceId, initialInvoices, accounts, baseCurrency, supportedCurrencies }: { workspaceId: string; initialInvoices: FinanceInvoice[]; accounts: AccountOption[]; baseCurrency: string; supportedCurrencies: string[] }) {
  const [invoices, setInvoices] = useState(initialInvoices)
  const [showForm, setShowForm] = useState(false)
  const [saving, setSaving] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [filterStatus, setFilterStatus] = useState<string>('all')
  const [filterDirection, setFilterDirection] = useState<string>('all')

  const [invoiceNumber, setInvoiceNumber] = useState('')
  const [accountId, setAccountId] = useState('')
  const [direction, setDirection] = useState<InvoiceDirection>('outgoing')
  const [status, setStatus] = useState<InvoiceStatus>('draft')
  const [issueDate, setIssueDate] = useState(new Date().toISOString().slice(0, 10))
  const [dueDate, setDueDate] = useState('')
  const [taxRate, setTaxRate] = useState('0')
  const [currency, setCurrency] = useState(baseCurrency)
  const [notes, setNotes] = useState('')
  const [lineItems, setLineItems] = useState<InvoiceLineItem[]>([])

  // Bill-to fields
  const [billToName, setBillToName] = useState('')
  const [billToAddress, setBillToAddress] = useState('')
  const [billToCity, setBillToCity] = useState('')
  const [billToPostcode, setBillToPostcode] = useState('')
  const [billToCountry, setBillToCountry] = useState('')
  const [billToEmail, setBillToEmail] = useState('')
  const [billToPhone, setBillToPhone] = useState('')
  const [billToVat, setBillToVat] = useState('')
  const [billToCompanyNumber, setBillToCompanyNumber] = useState('')

  const accountMap = new Map(accounts.map((a) => [a.id, a.name]))

  const resetBillTo = () => { setBillToName(''); setBillToAddress(''); setBillToCity(''); setBillToPostcode(''); setBillToCountry(''); setBillToEmail(''); setBillToPhone(''); setBillToVat(''); setBillToCompanyNumber('') }

  const handleAccountChange = (id: string) => {
    setAccountId(id)
    if (!id) { resetBillTo(); return }
    const acct = accounts.find((a) => a.id === id)
    if (!acct) return
    setBillToName(acct.name || '')
    setBillToAddress([acct.address_line1, acct.address_line2].filter(Boolean).join(', '))
    setBillToCity(acct.city || acct.state || '')
    setBillToPostcode(acct.postal_code || '')
    setBillToCountry(acct.country || '')
    setBillToEmail(acct.email || '')
    setBillToPhone(acct.phone || '')
  }

  const resetForm = () => { setInvoiceNumber(''); setAccountId(''); setDirection('outgoing'); setStatus('draft'); setIssueDate(new Date().toISOString().slice(0, 10)); setDueDate(''); setTaxRate('0'); setCurrency(baseCurrency); setNotes(''); setLineItems([]); setEditingId(null); resetBillTo() }

  const addLineItem = () => setLineItems((prev) => [...prev, { id: crypto.randomUUID(), description: '', quantity: 1, unit_price: 0, total: 0 }])
  const removeLineItem = (id: string) => setLineItems((prev) => prev.filter((i) => i.id !== id))
  const updateLineItem = (id: string, field: string, value: string | number) => {
    setLineItems((prev) => prev.map((item) => {
      if (item.id !== id) return item
      const updated = { ...item, [field]: value }
      updated.total = updated.quantity * updated.unit_price
      return updated
    }))
  }

  const openEdit = (inv: FinanceInvoice) => {
    setInvoiceNumber(inv.invoice_number); setAccountId(inv.account_id || ''); setDirection(inv.direction)
    setStatus(inv.status); setIssueDate(inv.issue_date); setDueDate(inv.due_date || '')
    setTaxRate(inv.tax_rate.toString()); setCurrency(inv.currency); setNotes(inv.notes || '')
    setLineItems(inv.line_items || []); setEditingId(inv.id); setShowForm(true)
    setBillToName(inv.bill_to_name || ''); setBillToAddress(inv.bill_to_address || ''); setBillToCity(inv.bill_to_city || '')
    setBillToPostcode(inv.bill_to_postcode || ''); setBillToCountry(inv.bill_to_country || ''); setBillToEmail(inv.bill_to_email || '')
    setBillToPhone(inv.bill_to_phone || ''); setBillToVat(inv.bill_to_vat_number || ''); setBillToCompanyNumber(inv.bill_to_company_number || '')
  }

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true)
    try {
    const payload = {
      workspace_id: workspaceId, invoice_number: invoiceNumber, account_id: accountId || null,
      direction, status, issue_date: issueDate, due_date: dueDate || null,
      tax_rate: parseFloat(taxRate) || 0, currency, notes: notes || null, line_items: lineItems,
      bill_to_name: billToName || null, bill_to_address: billToAddress || null, bill_to_city: billToCity || null,
      bill_to_postcode: billToPostcode || null, bill_to_country: billToCountry || null, bill_to_email: billToEmail || null,
      bill_to_phone: billToPhone || null, bill_to_vat_number: billToVat || null, bill_to_company_number: billToCompanyNumber || null,
    }
    if (editingId) {
      const subtotal = lineItems.reduce((s, i) => s + i.quantity * i.unit_price, 0)
      const taxAmount = subtotal * ((parseFloat(taxRate) || 0) / 100)
      const total = subtotal + taxAmount
      const { invoice } = await apiFetch<{ invoice: FinanceInvoice }>(`/api/finance/invoices/${editingId}?workspace_id=${workspaceId}`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...payload, subtotal, tax_amount: taxAmount, total, line_items: lineItems }),
      })
      setInvoices((prev) => prev.map((i) => i.id === editingId ? invoice : i))
    } else {
      const { invoice } = await apiFetch<{ invoice: FinanceInvoice }>('/api/finance/invoices', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
      setInvoices((prev) => [invoice, ...prev])
    }
    resetForm(); setShowForm(false)
    toast.success(editingId ? 'Invoice updated' : 'Invoice created')
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Something went wrong')
    } finally {
      setSaving(false)
    }
  }, [workspaceId, editingId, invoiceNumber, accountId, direction, status, issueDate, dueDate, taxRate, currency, notes, lineItems, billToName, billToAddress, billToCity, billToPostcode, billToCountry, billToEmail, billToPhone, billToVat, billToCompanyNumber])

  const handleDelete = useCallback(async (id: string) => {
    try {
      await apiFetch(`/api/finance/invoices/${id}?workspace_id=${workspaceId}`, { method: 'DELETE' })
      setInvoices((prev) => prev.filter((i) => i.id !== id))
      toast.success('Invoice deleted')
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to delete')
    }
  }, [workspaceId])

  const filtered = invoices.filter((i) => {
    if (filterStatus !== 'all' && i.status !== filterStatus) return false
    if (filterDirection !== 'all' && i.direction !== filterDirection) return false
    return true
  })

  const totals = useMemo(() => ({
    outstanding: filtered.filter((i) => !['paid', 'cancelled', 'refunded'].includes(i.status)).reduce((s, i) => s + i.total - i.amount_paid, 0),
    paid: filtered.filter((i) => i.status === 'paid').reduce((s, i) => s + i.total, 0),
  }), [filtered])

  const fmtCurrency = (v: number, code?: string) => {
    const sym = currencySymbol(code || baseCurrency)
    return `${sym}${v.toLocaleString(undefined, { minimumFractionDigits: 2 })}`
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs uppercase tracking-[0.2em] text-slate-400">Finance</p>
          <h1 className="mt-1 text-2xl font-semibold">Invoices</h1>
          <p className="mt-1 text-sm text-slate-400">Outstanding: {fmtCurrency(totals.outstanding)} &middot; Paid: {fmtCurrency(totals.paid)}</p>
        </div>
        <button onClick={async () => { resetForm(); setShowForm(true); try { const { next_number } = await apiFetch<{ next_number: string }>(`/api/finance/invoices/next-number?workspace_id=${workspaceId}`); setInvoiceNumber(next_number) } catch { /* user can enter manually */ } }} className="rounded-lg bg-white/90 px-4 py-1.5 text-xs font-semibold uppercase tracking-wide text-slate-950 hover:bg-white">+ New Invoice</button>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className="rounded-lg border border-slate-700 bg-slate-950 px-3 py-1.5 text-sm text-slate-200">
          <option value="all">All statuses</option>
          {INVOICE_STATUSES.map((s) => <option key={s} value={s}>{INVOICE_STATUS_LABELS[s]}</option>)}
        </select>
        <select value={filterDirection} onChange={(e) => setFilterDirection(e.target.value)} className="rounded-lg border border-slate-700 bg-slate-950 px-3 py-1.5 text-sm text-slate-200">
          <option value="all">All directions</option>
          <option value="incoming">Incoming</option>
          <option value="outgoing">Outgoing</option>
        </select>
      </div>

      {showForm && (
        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-6">
          <h2 className="text-lg font-semibold">{editingId ? 'Edit Invoice' : 'New Invoice'}</h2>
          <form onSubmit={handleSubmit} className="mt-4 space-y-4">
            <div className="grid gap-4 sm:grid-cols-3">
              <div><label className="mb-1 block text-xs text-slate-400">Invoice # *</label><input required value={invoiceNumber} onChange={(e) => setInvoiceNumber(e.target.value)} className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm" /></div>
              <div><label className="mb-1 block text-xs text-slate-400">Account</label><select value={accountId} onChange={(e) => handleAccountChange(e.target.value)} className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm"><option value="">None</option>{accounts.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}</select></div>
              <div><label className="mb-1 block text-xs text-slate-400">Direction</label><select value={direction} onChange={(e) => setDirection(e.target.value as InvoiceDirection)} className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm"><option value="outgoing">Outgoing</option><option value="incoming">Incoming</option></select></div>
              <div><label className="mb-1 block text-xs text-slate-400">Issue Date</label><input type="date" value={issueDate} onChange={(e) => setIssueDate(e.target.value)} className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm" /></div>
              <div><label className="mb-1 block text-xs text-slate-400">Due Date</label><input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm" /></div>
              <div><label className="mb-1 block text-xs text-slate-400">Tax Rate (%)</label><input type="number" step="0.01" value={taxRate} onChange={(e) => setTaxRate(e.target.value)} className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm" /></div>
              <div><label className="mb-1 block text-xs text-slate-400">Currency</label><select value={currency} onChange={(e) => setCurrency(e.target.value)} className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm">{supportedCurrencies.map((c) => <option key={c} value={c}>{c}</option>)}</select></div>
            </div>

            {/* Bill To */}
            <div>
              <p className="text-xs uppercase tracking-[0.15em] text-slate-400 mb-2">{direction === 'outgoing' ? 'Bill To' : 'Received From'}</p>
              <div className="grid gap-3 sm:grid-cols-3">
                <div><label className="mb-1 block text-xs text-slate-400">Name</label><input value={billToName} onChange={(e) => setBillToName(e.target.value)} className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm" /></div>
                <div><label className="mb-1 block text-xs text-slate-400">Email</label><input value={billToEmail} onChange={(e) => setBillToEmail(e.target.value)} className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm" /></div>
                <div><label className="mb-1 block text-xs text-slate-400">Phone</label><input value={billToPhone} onChange={(e) => setBillToPhone(e.target.value)} className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm" /></div>
                <div className="sm:col-span-3"><label className="mb-1 block text-xs text-slate-400">Address</label><input value={billToAddress} onChange={(e) => setBillToAddress(e.target.value)} className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm" /></div>
                <div><label className="mb-1 block text-xs text-slate-400">City / State</label><input value={billToCity} onChange={(e) => setBillToCity(e.target.value)} className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm" /></div>
                <div><label className="mb-1 block text-xs text-slate-400">Postcode</label><input value={billToPostcode} onChange={(e) => setBillToPostcode(e.target.value)} className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm" /></div>
                <div><label className="mb-1 block text-xs text-slate-400">Country</label><input value={billToCountry} onChange={(e) => setBillToCountry(e.target.value)} className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm" /></div>
                <div><label className="mb-1 block text-xs text-slate-400">VAT Number</label><input value={billToVat} onChange={(e) => setBillToVat(e.target.value)} className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm" /></div>
                <div><label className="mb-1 block text-xs text-slate-400">Company Number</label><input value={billToCompanyNumber} onChange={(e) => setBillToCompanyNumber(e.target.value)} className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm" /></div>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs text-slate-400">Line Items</label>
                <button type="button" onClick={addLineItem} className="text-xs text-blue-400 hover:text-blue-300">+ Add item</button>
              </div>
              {lineItems.map((item) => (
                <div key={item.id} className="mb-2 grid grid-cols-12 gap-2 items-center">
                  <input placeholder="Description" value={item.description} onChange={(e) => updateLineItem(item.id, 'description', e.target.value)} className="col-span-5 rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm" />
                  <input type="number" placeholder="Qty" value={item.quantity} onChange={(e) => updateLineItem(item.id, 'quantity', parseFloat(e.target.value) || 0)} className="col-span-2 rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm" />
                  <input type="number" step="0.01" placeholder="Price" value={item.unit_price} onChange={(e) => updateLineItem(item.id, 'unit_price', parseFloat(e.target.value) || 0)} className="col-span-2 rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm" />
                  <span className="col-span-2 text-right text-sm text-slate-300">{fmtCurrency(item.quantity * item.unit_price)}</span>
                  <button type="button" onClick={() => removeLineItem(item.id)} className="col-span-1 text-xs text-rose-400 hover:text-rose-300">×</button>
                </div>
              ))}
            </div>

            <div><label className="mb-1 block text-xs text-slate-400">Notes</label><textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm" /></div>
            <div className="flex gap-2">
              <button type="submit" className="rounded-lg bg-white/90 px-4 py-2 text-xs font-semibold uppercase text-slate-950 hover:bg-white">{editingId ? 'Update' : 'Create'}</button>
              <button type="button" onClick={() => { setShowForm(false); resetForm() }} className="rounded-lg border border-slate-700 px-4 py-2 text-xs uppercase text-slate-300 hover:text-white">Cancel</button>
            </div>
          </form>
        </div>
      )}

      <div className="overflow-x-auto rounded-2xl border border-slate-800">
        <table className="w-full text-sm">
          <thead><tr className="border-b border-slate-800 bg-slate-900/50 text-left text-xs uppercase tracking-wider text-slate-400">
            <th className="px-4 py-3">Invoice #</th><th className="px-4 py-3">Account</th><th className="px-4 py-3">Dir.</th><th className="px-4 py-3">Date</th><th className="px-4 py-3">Due</th><th className="px-4 py-3">Total</th><th className="px-4 py-3">Paid</th><th className="px-4 py-3">Status</th><th className="px-4 py-3"></th>
          </tr></thead>
          <tbody>
            {filtered.length === 0 ? <tr><td colSpan={9} className="px-4 py-8 text-center text-slate-500">No invoices found</td></tr> : filtered.map((inv) => (
              <tr key={inv.id} className="border-b border-slate-800/50 hover:bg-white/[0.02]">
                <td className="px-4 py-3 font-medium">{inv.invoice_number}</td>
                <td className="px-4 py-3 text-slate-400">{inv.account_id ? <Link href={`/workspace/${workspaceId}/accounts`} className="hover:text-white hover:underline">{accountMap.get(inv.account_id) || '—'}</Link> : '—'}</td>
                <td className="px-4 py-3 text-slate-400">{inv.direction === 'incoming' ? '↓ In' : '↑ Out'}</td>
                <td className="px-4 py-3 text-slate-400">{inv.issue_date}</td>
                <td className="px-4 py-3 text-slate-400">{inv.due_date || '—'}</td>
                <td className="px-4 py-3 font-medium">{fmtCurrency(inv.total, inv.currency)} <span className="text-[10px] text-slate-500">{inv.currency}</span></td>
                <td className="px-4 py-3 text-slate-400">{fmtCurrency(inv.amount_paid, inv.currency)}</td>
                <td className="px-4 py-3"><span className={`text-xs ${INVOICE_STATUS_COLORS[inv.status]}`}>{INVOICE_STATUS_LABELS[inv.status]}</span></td>
                <td className="px-4 py-3"><div className="flex gap-2"><Link href={`/workspace/${workspaceId}/invoices/${inv.id}`} className="text-xs text-blue-400 hover:text-blue-300">View</Link><button onClick={() => openEdit(inv)} className="text-xs text-slate-400 hover:text-white">Edit</button><a href={`/api/finance/invoices/${inv.id}/pdf`} download className="text-xs text-slate-400 hover:text-slate-200">PDF</a><button onClick={() => handleDelete(inv.id)} className="text-xs text-rose-400 hover:text-rose-300">Delete</button></div></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
