import type { ReactNode } from 'react'
import { redirect } from 'next/navigation'
import OsShell from '@/components/os/OsShell'
import { getCurrentProfile } from '@/lib/auth/roles'
import { getUnreadTaskCount, getUnreadMailCount, getUnreadMessagesCount, getUnreadMentionsCount } from '@/lib/notifications/unread'
import { createClient } from '@/lib/supabase/server'

export const dynamic = 'force-dynamic'

export default async function OsLayout({
  children,
}: {
  children: ReactNode
}) {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect('/login')
  }

  let newEnquiryCount = 0
  let activeQuoteCount = 0
  let unreadTaskCount = 0
  let unreadMailCount = 0
  let unreadMessageCount = 0
  let unreadMentionsCount = 0

  try {
    const profile = await getCurrentProfile(supabase)
    if (profile?.person_id) unreadTaskCount = await getUnreadTaskCount(profile.person_id, supabase)
  } catch {
    unreadTaskCount = 0
  }

  try {
    unreadMailCount = await getUnreadMailCount(supabase)
  } catch {
    unreadMailCount = 0
  }

  try {
    unreadMessageCount = await getUnreadMessagesCount(user.id, supabase)
  } catch {
    unreadMessageCount = 0
  }

  try {
    unreadMentionsCount = await getUnreadMentionsCount(user.id, supabase)
  } catch {
    unreadMentionsCount = 0
  }

  try {
    const { count } = await supabase
      .from('enquiries')
      .select('id', { count: 'exact', head: true })
      .eq('status', 'new')

    newEnquiryCount = count ?? 0
  } catch {
    newEnquiryCount = 0
  }

  try {
    const { count } = await supabase
      .from('quotes')
      .select('id', { count: 'exact', head: true })
      .in('status', ['draft', 'review'])

    activeQuoteCount = count ?? 0
  } catch {
    activeQuoteCount = 0
  }

  return (
    <OsShell
      newEnquiryCount={newEnquiryCount}
      activeQuoteCount={activeQuoteCount}
      unreadTaskCount={unreadTaskCount}
      unreadMailCount={unreadMailCount}
      unreadMessageCount={unreadMessageCount}
      unreadMentionsCount={unreadMentionsCount}
      userId={user.id}
    >
      {children}
    </OsShell>
  )
}
